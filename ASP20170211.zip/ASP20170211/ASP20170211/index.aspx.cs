﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASP20170211
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string sUsername = TextUserName.Text.Trim();
                string sPwd = TextBoxPwd.Text.Trim();
                if(string.IsNullOrEmpty(sUsername) || string.IsNullOrEmpty(sPwd))
                {
                    Response.Write(@"<script>alert(""No Username or no Password..."");</script>");
                }
                else
                {
                    string sSql = "select count(*) from UserInfor where UserName=@UserName and Pwd=@Pwd";
                    SqlParameter[] paras = new SqlParameter[] {
                        new SqlParameter("@UserName",sUsername),
                        new SqlParameter("@Pwd",sPwd)
                        };
                    if(SqlHelper.Exists(sSql,paras))
                    {
                        Response.Redirect("UserM.aspx");
                    }
                    else
                    {
                        Response.Write(@"<script>alert(""Username or Password is Wrong! "");</script>");
                    }
                }
            }
            catch 
            {
                Response.Write(@"<script>alert(""The WebSite is under repairing..."");</script>");
            }
           
        }
    }
}