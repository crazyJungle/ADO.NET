﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

namespace ASP20170211
{
    public partial class UserI : System.Web.UI.Page
    {
        private int _id; //字段

        public int Id //属性
        {
            get 
            {
                try
                {
                    _id = Request.QueryString["Id"] == null ? 0 : Convert.ToInt32(Request.QueryString["Id"].ToString());
                }
                catch (Exception)
                {
                    //当Id不是一个int的时候
                    _id = 0;
                }
                return _id;
            }
            set { _id = value; }
        }

        //等价于 自动属性 public int id { get;set; }

        string connStr = ConfigurationManager.ConnectionStrings["sq_ruanmou"].ToString();
        SqlConnection con = null;
        public void OpenDB()
        {
            try
            {
                con = new SqlConnection(connStr);
                con.Open();
            }
            catch (Exception)
            {
                Response.Write("未知错误!");
            }
        }

        public string GetUserInfor() 
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(@"<table id=""tableUserI"">");//@ "" "" 转义""
            if (Id > 0)
            {
                OpenDB();
                string sSql = string.Format("select UserId,RealName,UserName,Pwd,PhoneNum,Sex,Phase from UserInfor where UserId={0}", Id);
                using (SqlCommand cmd = new SqlCommand(sSql, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            //读取数据
                            while (reader.Read())
                            {
                                sb.Append(string.Format("<tr><td>Id:</td><td>{0}</td></tr>", reader["UserId"].ToString()));
                                sb.Append(string.Format("<tr><td>姓名:</td><td>{0}</td></tr>", reader["RealName"].ToString()));
                                sb.Append(string.Format("<tr><td>用户名:</td><td>{0}</td></tr>", reader["UserName"].ToString()));
                                sb.Append(string.Format("<tr><td>密码:</td><td>{0}</td></tr>", reader["Pwd"].ToString()));
                                sb.Append(string.Format("<tr><td>电话号码:</td><td>{0}</td></tr>", reader["PhoneNum"].ToString()));
                                sb.Append(string.Format("<tr><td>性别:</td><td>{0}</td></tr>", reader["Sex"].ToString()));
                                sb.Append(string.Format("<tr><td>班级:</td><td>{0}</td></tr>", reader["Phase"].ToString()));
                            }
                        }
                        else
                        {
                            sb.Append("没有相关数据!");
                        }
                    }
                }
            }
            else
            {
                sb.Append("没有相关数据!");
            }
            sb.Append("</table>");
            return sb.ToString();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //获取Post传值
            string sUserName = Request.Form["username"];
            string sPwd = Request.Form["pwd"];
        }
    }
}