﻿/// <reference path="jquery-3.1.1.min.js" />
$(function () {
    $("#GridViewUserM tr:odd").addClass("oddColor");
    $("#GridViewUserM tr:even").addClass("evenColor");
});